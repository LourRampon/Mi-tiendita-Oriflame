import './App.css';
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Login from './components/Login';
import SearchBar from './components/SearchBar';
import Footer from './components/Footer';
import DevButton from './components/DevButton';
import ProductCard from './components/ProductCard';
import AddButton from './components/AddButton';

const products = [
  {
    id: 1,
    name: 'Oh! Sweet Gelato Vibes',
    brand: 'Oriflame',
    line: 'Perfumería',
    description: 'Aroma con notas de mango, vainilla y acorde gelato. Efecto frescura veraniega.',
    price: 299.90,
    image: 'images/perfume.png',
},
{
  id: 2,
  name: 'North For Men Sensitive Protect',
  brand: 'Oriflame',
  line: 'Linea: North For Men',
  description: 'Gel de ducha ideal para limpiar piel y cabello.',
  price: 169.90,
  image: 'images/gel de ducha.png',
},
{
  id: 3,
  name: 'Sérum Capilar Duologi',
  brand: 'Oriflame',
  line: 'Capilar Duologi',
  description: 'Sérum capilar sellador para reducir puntas abiertas.',
  price: 139.90,
  image: 'images/sérum capilar.png',
},
{
  id: 4,
  name: 'Oh! Sweet Gloss',
  brand: 'Oriflame',
  line: 'Maquillaje On Colour',
  description: 'Gloss para labios en 8 aromas y sabores distintos. Labios hermosos y humectados.',
  price: 49.90,
  image: 'images/Summer Gloss.png',
},
{
  id: 5,
  name: 'Perfecting Concealer Stick',
  brand: 'Oriflame',
  line: 'Maquillaje On Colour',
  description: 'Mini corrector en barra de textura cremosa. Práctico tamaño para llevarlo contigo.',
  price: 49.90,
  image: 'images/corrector en barra.png',
},
{
  id: 6,
  name: 'Pure Skin Paso 3',
  brand: 'Oriflame',
  line: 'Pure Skin',
  description: 'Crema matificante para imperfecciones. Usala para tu rutina de skincare.',
  price: 89.90,
  image: 'images/crema facial.png',
},
{
  id: 7,
  name: 'Oh! Sweet Gelato Vibes',
  brand: 'Oriflame',
  line: 'Cremas Age Revive',
  description: 'Crema para contorno de ojos, para todo tipo de piel. Minimiza la aparición de arrugas y ojeras.',
  price: 229.90,
  image: 'images/contorno de ojos.png',
},
{
  id: 8,
  name: 'Energising Exfoliating Shower Gel',
  brand: 'Oriflame',
  line: 'Love Nature',
  description: 'Aroma frambuesa con menta para una ducha exfoliante y energizante.',
  price: 119.90,
  image: 'images/exfoliante.png',
},
{
  id: 9,
  name: 'Greater for Her',
  brand: 'Oriflame',
  line: 'Perfumería',
  description: 'Aroma con notas de mandarina, nardo y ámbar blanco.',
  price: 299.90,
  image: 'images/greater mujer.png',
},
{
  id: 10,
  name: 'Jabon Refrescante Love Nature',
  brand: 'Oriflame',
  line: 'Love Nature',
  description: 'Jabón para una ducha refrescante con agua de coco y melón.',
  price: 29.90,
  image: 'images/jabón en barra.png',
},
{
  id: 11,
  name: 'Soul Focus',
  brand: 'Oriflame',
  line: 'Perfumería',
  description: 'Aroma con notas de pimienta negra, flores de violeta y ámbar ahumado.',
  price: 369.90,
  image: 'images/perfume soul.png',
},
{
  id: 12,
  name: 'Pure Skin Paso 1',
  brand: 'Oriflame',
  line: 'Pure Skin',
  description: 'Limpiador facial para imperfecciones primer paso.',
  price: 109.90,
  image: 'images/limpiador facial.png',
},
];

const App = () => {
  const renderProductRows = () => {
    const rows = [];
    for (let i = 0; i < products.length; i += 4) {
        const rowProducts = products.slice(i, i + 4);
        const row = (
            <div className="row" key={i}>
                {rowProducts.map((products) => (
                    <div className="col-md-4" key={products.id}>
                        <ProductCard product={products} />
                    </div>
                ))}
            </div>
        );
        rows.push(row);
    }
    return rows;
};
  const handleSearch = (searchTerm) => {
    const filteredProducts = products.filter((product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    console.log('Productos encontrados:', filteredProducts);
  };
  
  const handleDevButtonClick = (productId) => {
    console.log(`Producto ${productId} devuelto`);
  };

  const handleAddButtonClick = (productId) => {
    console.log(`Producto ${productId} agregado`);
  };
  
return (
  <div className="App">
    <Navbar />
    <Header /> 
    <Login />
    <Footer/>
    <SearchBar onSearch={handleSearch} /> 
    {products.map((product) => (
      <div key={product.id}>
        <h3>{product.name}</h3>
        <AddButton onClick={() => handleAddButtonClick(product.id)} />
        <DevButton onClick={() => handleDevButtonClick(product.id)} />
      </div>))}
  </div>
);
};

export default App;
