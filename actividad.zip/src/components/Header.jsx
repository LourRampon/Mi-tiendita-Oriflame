import React from 'react';
import styles from './Header.css';

function Header () {
    return (
            <header className={styles.header}>
             <span>Bienvenido a nuestra tienda.</span>
                <h1>Conoce las ofertas especiales</h1>
                <p>
                   Adéntrate en las novedades del verano.
                   Conoce nuestros nuevos productos sustentables y sobre todo naturales.
                   Recuerda que nuestros productos no se prueban en animales. 
                </p>
            </header>
    ); 
};

export default Header;