import React from 'react';
import CartItem from './CartItem'; // Asegúrate de ajustar la ruta correcta

const Cart = ({ cartItems }) => {
  return (
    <div className="cart">
      <h2>Carrito de compras</h2>
      <ul>
        {cartItems.map((item) => (
          <CartItem key={item.id} item={item} />
        ))}
      </ul>
    </div>
  );
};

export default Cart;