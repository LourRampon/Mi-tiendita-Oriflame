import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      {/* Contenido del footer */}
      © 2024 Mi Tienda Online
    </footer>
  );
};

export default Footer;
