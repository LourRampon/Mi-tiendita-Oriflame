import React from 'react';

const ProductDetails = ({ products }) => {
  const { id, name, brand, line, description, price, image } = products;

  return (
    <div>
      <h2>Detalles del producto</h2>
      <p>ID del producto: {products.id}</p>
      <p>Nombre: {products.name}</p>
      <p>Marca: {products.brand}</p>
      <p>Línea: {products.line}</p>
      <p>Descripción: {products.description}</p>
      <p>Precio: ${products.price}</p>
      {/* Agrega más detalles aquí, como imágenes, categorías, etc. */}
      <img src={products.image} alt={products.name} />
    </div>
  );
};

export default ProductDetails;
