import React from 'react';

const Navbar = () => {
    const estilo = {
        backgroundColor: 'beige',
        fontSize: '18px',
        padding: '20px',
        position: 'relative',
        float: 'left',
        color: 'cornflowerblue',
        display: 'block'
    };

    return (
        <div style={estilo}>
            <nav className="navbar">
             <ul>
                <li><a href="#">Inicio</a></li>
                <li><a href="#">Servicios</a></li>
                <li><a href="#">Productos</a></li>
                <li><a href="#">Contacto</a></li>
             </ul>
            </nav>
        </div>
    ); 
};

export default Navbar;